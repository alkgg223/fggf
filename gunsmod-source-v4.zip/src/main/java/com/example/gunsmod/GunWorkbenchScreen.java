package com.example.gunsmod;

import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

public class GunWorkbenchScreen extends AbstractContainerScreen<GunWorkbenchMenu> {
    private static final int ROW_H = 16;
    private static final int ROWS = 11;
    private int selected = 0;
    private int scroll = 0;
    private float yaw = -35f;
    private boolean dragging = false;

    public GunWorkbenchScreen(GunWorkbenchMenu menu, Inventory inv, Component title) {
        super(menu, inv, title);
        this.imageWidth = 400;
        this.imageHeight = 232;
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mx, int my) {
    }

    private int listX() { return leftPos + 8; }
    private int listY() { return topPos + 46; }
    private int rightX() { return leftPos + 158; }
    private int craftX() { return rightX(); }
    private int craftY() { return topPos + 206; }

    private boolean canCraft() {
        WorkbenchRecipes.Entry e = WorkbenchRecipes.all().get(selected);
        return minecraft != null && minecraft.player != null && WorkbenchRecipes.canAfford(minecraft.player, e.costs());
    }

    @Override
    protected void renderBg(GuiGraphics g, float pt, int mx, int my) {
        int x = leftPos, y = topPos;
        g.fill(x, y, x + imageWidth, y + imageHeight, 0xF00C1015);
        g.fill(x, y, x + imageWidth, y + 1, 0xFF2A323C);
        for (int gx = x; gx < x + imageWidth; gx += 16) g.fill(gx, y, gx + 1, y + imageHeight, 0x10FFFFFF);
        for (int gy = y; gy < y + imageHeight; gy += 16) g.fill(x, gy, x + imageWidth, gy + 1, 0x10FFFFFF);
        GunPreview.small(g, font, "\u2022 WORKSHOP", x + 8, y + 6, 0xFFE0A030, 0.8f);
        GunPreview.small(g, font, "Gun Workbench", x + 8, y + 17, 0xFFFFFFFF, 1.6f);

        List<WorkbenchRecipes.Entry> list = WorkbenchRecipes.all();
        int lx = listX(), ly = listY();
        g.fill(lx, ly, lx + 140, ly + ROWS * ROW_H, 0xFF11161C);
        g.enableScissor(lx, ly, lx + 140, ly + ROWS * ROW_H);
        for (int i = 0; i < list.size(); i++) {
            int ry = ly + (i - scroll) * ROW_H;
            if (ry + ROW_H < ly || ry > ly + ROWS * ROW_H) continue;
            boolean sel = i == selected;
            boolean hov = mx >= lx && mx < lx + 140 && my >= ry && my < ry + ROW_H && my >= ly && my < ly + ROWS * ROW_H;
            if (sel) g.fill(lx, ry, lx + 140, ry + ROW_H, 0xFF7A5416);
            else if (hov) g.fill(lx, ry, lx + 140, ry + ROW_H, 0xFF1E252D);
            g.pose().pushPose();
            g.pose().translate(lx + 2, ry + 3, 0);
            g.pose().scale(0.625f, 0.625f, 1f);
            g.renderItem(new ItemStack(list.get(i).result().get()), 0, 0);
            g.pose().popPose();
            g.drawString(font, new ItemStack(list.get(i).result().get()).getHoverName(), lx + 16, ry + 4, sel ? 0xFFFFFFFF : 0xFFC8CFD8, false);
        }
        g.disableScissor();
        if (list.size() > ROWS) {
            int bh = Math.max(12, ROWS * ROW_H * ROWS / list.size());
            int by = ly + (ROWS * ROW_H - bh) * scroll / Math.max(1, list.size() - ROWS);
            g.fill(lx + 138, by, lx + 140, by + bh, 0xFF6A7380);
        }

        int rx = rightX(), rw = x + imageWidth - 8 - rx;
        g.fill(rx, y + 46, rx + rw, y + 134, 0xFF11161C);
        WorkbenchRecipes.Entry e = list.get(selected);
        ItemStack out = new ItemStack(e.result().get(), e.count());
        GunPreview.draw(g, out, rx + rw / 2f, y + 90, e.gun() != null ? 150f : 52f, yaw, 8f);
        if (e.gun() != null) GunPreview.small(g, font, "drag to rotate", rx + 4, y + 124, 0xFF5E6672, 0.7f);

        GunPreview.small(g, font, out.getHoverName().getString(), rx, y + 140, 0xFFFFFFFF, 1.5f);
        if (e.gun() != null) {
            GunType t = e.gun();
            String dmg = t.pellets > 1 ? t.damage + "x" + t.pellets : String.valueOf(t.damage);
            String ammoName = GunsMod.AMMO_ITEMS.get(t).get().getDescription().getString();
            String sub = ammoName + "  \u00B7  " + dmg + " dmg  \u00B7  " + (1200 / Math.max(1, t.fireDelay)) + " rpm  \u00B7  " + t.magSize + " rds";
            GunPreview.small(g, font, sub, rx, y + 158, 0xFF8A919C, 0.85f);
        } else {
            GunPreview.small(g, font, "x" + e.count() + " per craft", rx, y + 158, 0xFF8A919C, 0.85f);
        }
        GunPreview.small(g, font, "\u2022 Requires", rx, y + 172, 0xFFE0A030, 0.85f);
        boolean creative = minecraft != null && minecraft.player != null && minecraft.player.getAbilities().instabuild;
        for (int i = 0; i < e.costs().size(); i++) {
            WorkbenchRecipes.Cost c = e.costs().get(i);
            int cx = rx + i * 58, cy = y + 184;
            g.fill(cx, cy, cx + 54, cy + 18, 0xFF141A21);
            g.fill(cx, cy, cx + 54, cy + 1, 0xFF3A4450);
            g.renderItem(new ItemStack(c.item().get()), cx + 1, cy + 1);
            int have = minecraft != null && minecraft.player != null ? WorkbenchRecipes.count(minecraft.player, c.item().get()) : 0;
            boolean ok = creative || have >= c.count();
            g.drawString(font, (creative ? "\u221E" : String.valueOf(have)) + "/" + c.count(), cx + 19, cy + 5, ok ? 0xFF6BE070 : 0xFFFF6B6B, false);
        }

        boolean can = canCraft();
        int bx = craftX(), by = craftY();
        boolean hov = mx >= bx && mx < bx + 100 && my >= by && my < by + 18;
        g.fill(bx, by, bx + 100, by + 18, can ? (hov ? 0xFFF0B040 : 0xFFD9962A) : 0xFF3A404A);
        String label = can ? "Craft" : "Missing items";
        g.drawString(font, label, bx + (100 - font.width(label)) / 2, by + 5, can ? 0xFF1A1206 : 0xFF8A919C, false);
        boolean hov5 = mx >= bx + 106 && mx < bx + 142 && my >= by && my < by + 18;
        g.fill(bx + 106, by, bx + 142, by + 18, can ? (hov5 ? 0xFFF0B040 : 0xFFD9962A) : 0xFF3A404A);
        g.drawString(font, "x5", bx + 106 + (36 - font.width("x5")) / 2, by + 5, can ? 0xFF1A1206 : 0xFF8A919C, false);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        super.render(g, mx, my, pt);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        int n = WorkbenchRecipes.all().size();
        if (mx >= listX() && mx < listX() + 140) {
            scroll = Math.max(0, Math.min(Math.max(0, n - ROWS), scroll - (int) Math.signum(sy)));
            return true;
        }
        return super.mouseScrolled(mx, my, sx, sy);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging) {
            yaw += (float) dx * 1.2f;
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragging = false;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        List<WorkbenchRecipes.Entry> list = WorkbenchRecipes.all();
        int lx = listX(), ly = listY();
        if (mx >= lx && mx < lx + 140 && my >= ly && my < ly + ROWS * ROW_H) {
            int i = (int) ((my - ly) / ROW_H) + scroll;
            if (i >= 0 && i < list.size()) selected = i;
            return true;
        }
        if (mx >= rightX() && mx < leftPos + imageWidth - 8 && my >= topPos + 46 && my < topPos + 134) {
            dragging = true;
            return true;
        }
        int bx = craftX(), by = craftY();
        if (my >= by && my < by + 18 && minecraft != null && minecraft.gameMode != null && canCraft()) {
            if (mx >= bx && mx < bx + 100) {
                minecraft.gameMode.handleInventoryButtonClick(menu.containerId, selected);
                return true;
            }
            if (mx >= bx + 106 && mx < bx + 142) {
                for (int k = 0; k < 5; k++) {
                    if (!canCraft()) break;
                    minecraft.gameMode.handleInventoryButtonClick(menu.containerId, selected);
                }
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }
}
