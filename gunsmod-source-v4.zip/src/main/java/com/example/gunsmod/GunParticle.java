package com.example.gunsmod;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/**
 * Pixel-art gun / explosion particles. Muzzle flash, smoke and explosion are frame animations
 * (textures/particle/muz_*, smk_*, exp_*) that play over the particle's lifetime. Client only.
 */
public class GunParticle extends TextureSheetParticle {
    public enum Kind { SMOKE_S, SMOKE_M, SMOKE_L, DUST, FLASH_S, FLASH_L, SPARK, FIRE }

    private final Kind kind;
    private final SpriteSet sprites;
    private final float shade;
    private Vec3 flashDir;

    protected GunParticle(ClientLevel level, double x, double y, double z, double vx, double vy, double vz,
                          SpriteSet sprites, Kind kind) {
        super(level, x, y, z);
        this.sprites = sprites;
        this.kind = kind;
        this.xd = vx;
        this.yd = vy;
        this.zd = vz;
        this.hasPhysics = kind == Kind.SPARK;
        this.shade = 0.8f + this.random.nextFloat() * 0.2f;
        float r = this.random.nextFloat();
        this.rCol = this.gCol = this.bCol = 1f;
        switch (kind) {
            case SMOKE_S -> { quadSize = 0.22f + r * 0.1f; lifetime = 14 + random.nextInt(8); friction = 0.86f; gravity = -0.01f; }
            case SMOKE_M -> { quadSize = 0.6f + r * 0.25f; lifetime = 34 + random.nextInt(14); friction = 0.9f; gravity = -0.012f; }
            case SMOKE_L -> { quadSize = 1.7f + r * 0.8f; lifetime = 70 + random.nextInt(30); friction = 0.94f; gravity = -0.02f; }
            case DUST -> { quadSize = 0.35f + r * 0.2f; lifetime = 18 + random.nextInt(8); friction = 0.82f; gravity = 0.005f;
                rCol = 0.95f; gCol = 0.85f; bCol = 0.68f; }
            case FLASH_S -> { quadSize = 0.5f + r * 0.2f; lifetime = 4 + random.nextInt(2); friction = 0.5f; gravity = 0f; stop();
                double len = Math.sqrt(vx * vx + vy * vy + vz * vz);
                if (len > 1.0E-6) flashDir = new Vec3(vx / len, vy / len, vz / len); }
            case FLASH_L -> { quadSize = 3.0f + r * 0.8f; lifetime = 30; friction = 0.5f; gravity = 0f; stop(); }
            case SPARK -> { quadSize = 0.03f + r * 0.025f; lifetime = 10 + random.nextInt(14); friction = 0.9f; gravity = 0.55f;
                gCol = 0.85f; bCol = 0.45f; }
            default -> { quadSize = 0.8f + r * 0.8f; lifetime = 10 + random.nextInt(5); friction = 0.9f; gravity = -0.005f; }
        }
        if (kind == Kind.SMOKE_S || kind == Kind.SMOKE_M || kind == Kind.SMOKE_L || kind == Kind.DUST || kind == Kind.FLASH_L || kind == Kind.FIRE) {
            this.roll = this.oRoll = (float) (Math.PI / 2 * random.nextInt(4)); // quarter turns keep the pixels aligned
        }
        this.setSpriteFromAge(sprites);
        this.alpha = 1f;
    }

    private void stop() {
        this.xd = 0;
        this.yd = 0;
        this.zd = 0;
    }

    @Override
    public void tick() {
        super.tick();
        if (removed) return;
        this.setSpriteFromAge(sprites);
        float t = Math.min(1f, (float) age / (float) lifetime);
        switch (kind) {
            case SMOKE_S, SMOKE_M, SMOKE_L -> alpha = 0.92f * shade;
            case DUST -> alpha = 0.75f * (1f - t * t);
            case SPARK -> { alpha = 1f - t * t * t; gCol = 0.85f - 0.5f * t; bCol = 0.45f - 0.4f * t; quadSize = Math.max(0.01f, quadSize * 0.97f); }
            default -> alpha = 1f;
        }
    }

    @Override
    public void render(VertexConsumer buffer, Camera camera, float partialTicks) {
        if (flashDir != null) { // point the flame along the shot direction on screen
            Vector3f left = camera.getLeftVector();
            Vector3f up = camera.getUpVector();
            double dr = -(flashDir.x * left.x() + flashDir.y * left.y() + flashDir.z * left.z());
            double du = flashDir.x * up.x() + flashDir.y * up.y() + flashDir.z * up.z();
            float r = (dr * dr + du * du > 0.02) ? (float) Math.atan2(-du, dr) : 0f;
            this.roll = r;
            this.oRoll = r;
        }
        super.render(buffer, camera, partialTicks);
    }

    @Override
    protected int getLightColor(float partialTick) {
        if (kind == Kind.FLASH_S || kind == Kind.FLASH_L || kind == Kind.SPARK) return LightTexture.FULL_BRIGHT;
        if (kind == Kind.FIRE) return LightTexture.FULL_BRIGHT;
        return super.getLightColor(partialTick);
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    public static class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;
        private final Kind kind;

        public Provider(SpriteSet sprites, Kind kind) {
            this.sprites = sprites;
            this.kind = kind;
        }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z,
                                       double xd, double yd, double zd) {
            return new GunParticle(level, x, y, z, xd, yd, zd, sprites, kind);
        }
    }
}
